# $CHIMP — Website

A single-page, no-build, static site. No framework, no bundler — just HTML, CSS and JS, ready to deploy as-is.

## Project structure

```
chimp-website/
├── index.html              ← main entry file
├── css/
│   └── styles.css          ← all styles
├── js/
│   └── main.js              ← nav, mobile menu, mascot animation, support widget
├── assets/
│   └── images/
│       ├── chimp-mascot.webp   ← hero / "Meet CHIMP" / gallery image
│       ├── chimp-icon.webp     ← favicon + nav/footer logo
│       ├── meme-duotone.webp   ← meme gallery variant
│       └── meme-glitch.webp    ← meme gallery variant
├── _headers                 ← Cloudflare Pages cache-control rules
├── .gitignore
└── README.md
```

All image, CSS and JS paths in `index.html` are **relative**, so the folder can be moved, zipped, or uploaded anywhere without breaking.

## Links already wired in the code

| Purpose        | URL                                             | Where it's used                                   |
|-----------------|--------------------------------------------------|----------------------------------------------------|
| Buy $CHIMP      | https://pump.fun/join/unlikesalmon140            | Nav, hero, token section, mobile menu               |
| Community       | https://t.me/chimpbuytld                         | Nav, hero, token section, community, footer, gallery CTA |
| Telegram        | https://t.me/chimpbuytld                         | Community section, footer                           |
| X / Twitter     | https://x.com/chimpltdtw4m                       | Community section, footer                           |
| Contract address| *(not yet available)*                            | Token section — shown as a clear "not deployed yet" placeholder with a Copy button |

**Nothing about the contract address, supply, tax, liquidity, market cap, holders, or exchange listings is invented.** Every one of those fields is intentionally marked `TBA` until real data exists. When the token deploys:

1. Open `index.html`.
2. Find `Contract address not yet deployed` inside `<div class="contract-row">` and replace it with the real address.
3. Replace the four `TBA` values in `<div class="token-grid">` (Network, Total supply, Tax/Fees, Liquidity) with real figures.
4. Never add market cap / holders / partnerships text unless it is independently verifiable at time of publishing.

## Support widget

The green circular button (bottom-right) and the "Support" nav item open a small FAQ panel. It answers a handful of common questions with **pre-written, static text** — there is no AI model or backend behind it, so it works instantly and costs nothing to host. Edit the `FAQ` array near the top of `js/main.js` to add, remove, or reword questions.

## Performance notes

- Images are compressed WebP, served as real files (not inlined), so the browser can cache them independently and in parallel.
- The hero image is preloaded (`<link rel="preload">`) and marked `fetchpriority="high"`; every other image below the fold uses `loading="lazy"`.
- All `<img>` tags carry explicit `width`/`height` to prevent layout shift while assets load.
- `_headers` tells Cloudflare Pages to cache `/assets`, `/css`, and `/js` for a year (`immutable`) and to always revalidate `index.html`, so future edits go live immediately while static assets stay cached.
- Fonts load from Google Fonts with `display=swap` and `preconnect` hints, so text renders immediately in a fallback font while the webfont loads.
- Animations respect `prefers-reduced-motion`.

## Deploying to Cloudflare Pages via GitHub

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial production site"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```

2. **Connect Cloudflare Pages**
   - Go to the Cloudflare dashboard → **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**.
   - Select the repository you just pushed.

3. **Build settings** — this is a static site, so:
   - Framework preset: `None`
   - Build command: *(leave empty)*
   - Build output directory: `/`

4. Click **Save and Deploy**. Cloudflare will build and give you a `*.pages.dev` URL immediately.

5. **Custom domain (optional)**: in the Pages project → **Custom domains** → add your domain and follow the DNS instructions.

Every future `git push` to `main` automatically redeploys the site.

## Local preview

No build step needed — just open `index.html` in a browser, or serve it locally:

```bash
python3 -m http.server 8080
# then visit http://localhost:8080
```
